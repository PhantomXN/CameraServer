/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.s10759030.serverside;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author PhantomXN
 */
public class Handle_Computing extends Thread {
    private Socket socket;
    private RunServer server;
    
    
    public Handle_Computing(Socket socket,RunServer server){
        this.socket= socket;
        this.server= server;
    }
    public void run(){
        Scanner input=null;
        PrintWriter output=null;
        try{
            input = new Scanner(socket.getInputStream());
            output = new PrintWriter(socket.getOutputStream(), true);
            String message;
            boolean invaded = false, loopA = false, loopB = false;
            do{
                Path fileName = Path.of("input.txt");
                String actual = Files.readString(fileName);
                if(actual.equals("true")){
                    invaded = true;
                }
                if(invaded && !loopA){
                    output.println(getCurrentTimeStamp() + " Someone Invaded!");
                    loopA = true;
                }
                else if (!invaded && loopA){
                    loopA = false;
                }
                invaded = false;
            }while(socket.isConnected());
            server.getWindow().txv.append("Client "+ socket.getPort() +" disconnected.\n");
        }catch(IOException ex){
            Logger.getLogger(Handle_Computing.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public String getCurrentTimeStamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }
}
