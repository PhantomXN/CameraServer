/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.s10759030.serverside;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author PhantomXN
 */
public class RunServer extends Thread{
    private ServerWin window;
    private ServerSocket server_socket;
    private int port;
    public RunServer(int port, ServerWin win) throws IOException {
        this.port = port;
        this.window = win;
        server_socket = new ServerSocket(port);
    }
    public void run(){
        Socket socket;
        window.txv.setText("Server is running \n");
        while (true){
            try{
                socket = server_socket.accept();
                window.txv.append("Client" + socket.getInetAddress()+":"+socket.getPort() + " connected.\n");
                new Handle_Computing(socket, this).start();
            }catch (IOException ex){
                Logger.getLogger(RunServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public ServerWin getWindow() {
        return this.window;
    }
}
